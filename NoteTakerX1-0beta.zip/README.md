#README
This is a notetaker created by Rusi, feel free to delete due to it uttter unusefulness!
